# Bitrix Local Agent V3 Addon

Первый слой V3 поверх рабочего V2. V2 не заменяет.

## Установка
1. Распаковать эти 4 файла внутрь `C:\Users\Admin\Desktop\Bitrix_Local_Agent_V2_MCP_Portable`.
2. Рабочий `.env` V2 оставить на месте.
3. Запустить `V3_DISCOVER_TEST.bat`.
4. Получившийся `exports\v3_discovery_test_*.json` передать в ChatGPT.

## Что делает
Только читает Bitrix: профиль, API шаблонов задач, список БП, проект/группу Test и задачи Test.
Создаёт локальную SQLite-память `memory\agent_memory.db` и черновой рецепт `PROJECT_TASK_CHAIN_V1`.

## Безопасность
На этом этапе нет вызовов add/update/delete. Следующий этап — PREVIEW, и только после отдельного подтверждения появится запись.
