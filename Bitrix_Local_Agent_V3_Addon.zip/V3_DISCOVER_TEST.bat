@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Bitrix Local Agent V3 - Test discovery - READ ONLY
python v3_agent.py
echo.
pause
