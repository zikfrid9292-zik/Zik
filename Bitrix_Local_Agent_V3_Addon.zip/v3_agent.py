# -*- coding: utf-8 -*-
import json,os,ssl,sys,urllib.request
from pathlib import Path
from datetime import datetime
from v3_memory import save_map,save_experiment,save_recipe
BASE=Path(__file__).resolve().parent; ENV=BASE/".env"; OUT=BASE/"exports"; OUT.mkdir(exist_ok=True)
if not ENV.exists(): raise RuntimeError("Нет .env рядом с v3_agent.py. Используйте рабочий .env из V2.")
for raw in ENV.read_text(encoding="utf-8").splitlines():
    s=raw.strip()
    if s and not s.startswith("#") and "=" in s:
        k,v=s.split("=",1); os.environ.setdefault(k.strip(),v.strip())
WEBHOOK=os.getenv("BITRIX_WEBHOOK_URL","").strip().rstrip("/")
VERIFY=os.getenv("BITRIX_SSL_VERIFY","true").lower() not in ("0","false","no","n")
if not WEBHOOK: raise RuntimeError("BITRIX_WEBHOOK_URL отсутствует в .env")
def call(method,params=None):
    req=urllib.request.Request(f"{WEBHOOK}/{method}.json",data=json.dumps(params or {},ensure_ascii=False).encode(),
        headers={"Content-Type":"application/json; charset=utf-8","Accept":"application/json"},method="POST")
    ctx=None if VERIFY else ssl._create_unverified_context()
    with urllib.request.urlopen(req,timeout=60,context=ctx) as r: data=json.loads(r.read().decode())
    if "error" in data: raise RuntimeError(f"{data.get('error')}: {data.get('error_description','')}")
    return data
def probe(method,params=None):
    try:
        x={"ok":True,"method":method,"data":call(method,params)}; save_experiment("TEST_PROJECT_BP_DISCOVERY",method,x,True); return x
    except Exception as e:
        x={"ok":False,"method":method,"error":str(e)}; save_experiment("TEST_PROJECT_BP_DISCOVERY",method,x,False); return x
def discover():
    print("Bitrix Agent V3 - READ ONLY DISCOVERY\n")
    report={"generated_at":datetime.now().isoformat(timespec="seconds"),"mode":"READ_ONLY","checks":[]}
    checks=[
      ("profile",{}),
      ("tasks.template.fields",{}),
      ("tasks.template.list",{"select":["ID","TITLE","RESPONSIBLE_ID","GROUP_ID","PARENT_ID"]}),
      ("bizproc.workflow.template.list",{"select":["ID","NAME","MODULE_ID","ENTITY","DOCUMENT_TYPE","AUTO_EXECUTE","USER_ID","SYSTEM_CODE"],"order":{"ID":"DESC"}}),
      ("sonet_group.get",{"FILTER":{"%NAME":"Test"}}),
      ("socialnetwork.api.workgroup.list",{"filter":{"search":"Test"}}),
      ("tasks.task.list",{"filter":{"%TITLE":"Test"},"select":["ID","TITLE","PARENT_ID","GROUP_ID","RESPONSIBLE_ID","CREATED_BY","DEADLINE","START_DATE_PLAN","END_DATE_PLAN","STATUS"],"order":{"ID":"DESC"}})
    ]
    for method,params in checks:
        print("[READ]",method,"...",end=" ",flush=True); r=probe(method,params); report["checks"].append(r); print("OK" if r["ok"] else "ERROR/NO ACCESS")
    save_map("test_project_discovery",report)
    goal="Проект Test: головная задача Test + подзадачи; перенос этапа сдвигает последующие сроки; выход за сроки проекта допустим; запуск через бизнес-процесс."
    save_recipe("PROJECT_TASK_CHAIN_V1","Test - цепочка задач проекта",goal,{"goal":goal,"phase":"discovery","write_enabled":False,"next":"build_preview"},"draft")
    path=OUT/f"v3_discovery_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print("\nГОТОВО:",path); print("Bitrix НЕ изменялся."); return path
if __name__=="__main__":
    try: discover()
    except Exception as e: print("\n[ERROR]",type(e).__name__,e); sys.exit(1)
