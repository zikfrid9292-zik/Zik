# -*- coding: utf-8 -*-
import sqlite3, json
from datetime import datetime
from pathlib import Path
BASE=Path(__file__).resolve().parent
DB=BASE/"memory"/"agent_memory.db"
def connect():
    DB.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(DB)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS recipes(id INTEGER PRIMARY KEY,code TEXT UNIQUE,title TEXT,goal TEXT,status TEXT,recipe_json TEXT,created_at TEXT,updated_at TEXT);
    CREATE TABLE IF NOT EXISTS experiments(id INTEGER PRIMARY KEY,task TEXT,action TEXT,result_json TEXT,success INTEGER,created_at TEXT);
    CREATE TABLE IF NOT EXISTS bitrix_map(key TEXT PRIMARY KEY,value_json TEXT,updated_at TEXT);
    """)
    con.commit(); return con
def save_map(key,value):
    now=datetime.now().isoformat(timespec="seconds")
    with connect() as con:
        con.execute("INSERT OR REPLACE INTO bitrix_map VALUES(?,?,?)",(key,json.dumps(value,ensure_ascii=False),now)); con.commit()
def save_experiment(task,action,result,success):
    with connect() as con:
        con.execute("INSERT INTO experiments(task,action,result_json,success,created_at) VALUES(?,?,?,?,?)",
        (task,action,json.dumps(result,ensure_ascii=False),int(bool(success)),datetime.now().isoformat(timespec="seconds"))); con.commit()
def save_recipe(code,title,goal,recipe,status="draft"):
    now=datetime.now().isoformat(timespec="seconds")
    with connect() as con:
        con.execute("""INSERT INTO recipes(code,title,goal,status,recipe_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?)
        ON CONFLICT(code) DO UPDATE SET title=excluded.title,goal=excluded.goal,status=excluded.status,recipe_json=excluded.recipe_json,updated_at=excluded.updated_at""",
        (code,title,goal,status,json.dumps(recipe,ensure_ascii=False),now,now)); con.commit()
